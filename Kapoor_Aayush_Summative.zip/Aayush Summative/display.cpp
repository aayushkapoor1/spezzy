#include <iostream>
#include "prototypes.h"
#include "object.h"
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

extern Image background;

void display_structure()
{

}
