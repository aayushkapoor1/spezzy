#ifndef DEFINES_H_INCLUDED
#define DEFINES_H_INCLUDED
///Sets up the screen display
#define SCREEN_W 1200
#define SCREEN_H 680

#define Black al_map_rgb(0, 0, 0)
#define Red al_map_rgb(0xaa, 0x12, 0x12)
#define White al_map_rgb(255, 250, 250)

#endif // DEFINES_H_INCLUDED
